-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 12, 2016 at 01:26 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kueultah`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kat` int(10) NOT NULL,
  `nama_kat` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kat`, `nama_kat`) VALUES
(1, 'kue biasa'),
(2, 'kue custom');

-- --------------------------------------------------------

--
-- Table structure for table `kue`
--

CREATE TABLE IF NOT EXISTS `kue` (
  `id_kue` int(11) NOT NULL,
  `nama_kue` varchar(50) NOT NULL,
  `harga` varchar(20) NOT NULL,
  `desc` text NOT NULL,
  `id_kat` int(10) NOT NULL,
  `gambar` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kue`
--

INSERT INTO `kue` (`id_kue`, `nama_kue`, `harga`, `desc`, `id_kat`, `gambar`) VALUES
(1, 'kue 1', '50000', 'ayo dibeli', 1, 'kue1.jpg'),
(2, 'Kue 2', '70000', 'Rugi kalo gak beli', 1, 'kue2.jpg'),
(3, 'Kue 10', '75000', 'Bisa Pakai Photo sendiri loh', 2, 'kue10.jpg'),
(4, 'Kue4', '50000', 'enak banget', 2, 'kue6.jpg'),
(5, 'coklat spesial', '120000', 'enak sekali , pasti ketagihan', 1, 'kue4.jpg'),
(6, 'coklat cantik', '150000', 'mmmmm lezat', 1, 'kue7.jpg'),
(7, 'bola salju', '120000', 'bisa pakai poto sendiri loh', 2, 'kue8.jpg'),
(8, 'coklat strobery', '150000', 'pakai poto lebih asik', 2, 'kue9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_belanja`
--

CREATE TABLE IF NOT EXISTS `tbl_belanja` (
  `id_blj` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `banyak` varchar(30) NOT NULL,
  `total` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_belanja`
--

INSERT INTO `tbl_belanja` (`id_blj`, `id_user`, `banyak`, `total`) VALUES
(5, 14, '', '1,680,000'),
(6, 14, '', '1,680,000'),
(7, 15, '', '2,355,000'),
(8, 15, '', '2,355,000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_keranjang`
--

CREATE TABLE IF NOT EXISTS `tbl_keranjang` (
  `id_pesan` int(10) NOT NULL,
  `id_user` int(10) NOT NULL,
  `id_kue` int(10) NOT NULL,
  `tgl_pesan` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `gambar` varchar(100) NOT NULL,
  `total` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_keranjang`
--

INSERT INTO `tbl_keranjang` (`id_pesan`, `id_user`, `id_kue`, `tgl_pesan`, `gambar`, `total`) VALUES
(17, 0, 0, '2015-12-26 17:46:00', '353282435567ed258d8aef5.81093720.jpg', ''),
(25, 14, 2, '2015-12-27 07:30:09', '', ''),
(26, 14, 2, '2015-12-27 08:11:27', '', ''),
(27, 14, 1, '2015-12-27 08:39:28', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id_user` int(10) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `nohp` varchar(12) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama`, `username`, `password`, `alamat`, `nohp`) VALUES
(13, 'alam', 'oohno', '$2y$10$pTOJUekuD0XjEMYenfgCYO39aVaofqAw6zS1.OvEr6DZ1GSxy4ABa', 'hhhh', '1111111'),
(14, 'yogi putra', 'oohyugi', '$2y$10$RDUzg2TE7XKIZsHIlj3r9eHLxr/IoBbdiFrXkpkus6x1aIARdVUPu', 'jln. berok rakik', '081270517467'),
(15, 'yogi', 'yogi', '$2y$10$6V9GRQ17rmzo04MA7bjeYOFqlj3yjtlsqW21VG1vsmRXkTCtgMfle', 'berok', '081993313134');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kat`);

--
-- Indexes for table `kue`
--
ALTER TABLE `kue`
  ADD PRIMARY KEY (`id_kue`);

--
-- Indexes for table `tbl_belanja`
--
ALTER TABLE `tbl_belanja`
  ADD PRIMARY KEY (`id_blj`);

--
-- Indexes for table `tbl_keranjang`
--
ALTER TABLE `tbl_keranjang`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kat` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kue`
--
ALTER TABLE `kue`
  MODIFY `id_kue` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_belanja`
--
ALTER TABLE `tbl_belanja`
  MODIFY `id_blj` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_keranjang`
--
ALTER TABLE `tbl_keranjang`
  MODIFY `id_pesan` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
