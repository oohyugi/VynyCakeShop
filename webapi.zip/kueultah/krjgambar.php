<?php
/* Code for sign up*/
require "koneksi.php";
//check for required fields
	//get data from post
	$id_user = $_POST['id_user'];
	$id_kue = $_POST['id_kue'];
  $tmpName = $_FILES['attachment']['tmp_name'];
$fileType = $_FILES['attachment']['type'];
$fileName = time() . '.jpg'; //use this name
move_uploaded_file($_FILES['attachment']['tmp_name'], "uploads/" . $fileName);

	// using password hash




			//bulide query
			$insert = "INSERT INTO tbl_keranjang (id_user,id_kue,gambar) values('$id_user','$id_kue','$fileName')";
			//insert to datavase
			$res_ins = mysqli_query($koneksi, $insert);
			//check if saved work fine
			if ($res_ins) {
				//return user info to app
        $post['result'] = "successfull";
	$data = 'content-type:application/json';
	$data = json_encode($post);
	echo $data;



			} else {
				//catch database error
        $post['result'] = $connection->error;
  	$data = 'content-type:application/json';
  	$data = json_encode($post);
  	echo $data;
			}



?>
