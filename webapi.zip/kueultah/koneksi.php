<?php
$host="localhost";
$user="root";
$pass="";
$db="kueultah";
$koneksi=mysqli_connect($host,$user,$pass,$db);
?>
