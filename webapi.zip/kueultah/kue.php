<?php
/**
*
*/
require 'koneksi.php';
$response=array();


$id_kat=$_GET['id_kat'];



//ambil semua data
$hasil1= mysqli_query($koneksi,"SELECT * From kue where id_kat='$id_kat'")or die(mysql_error());
if (mysqli_num_rows($hasil1)>0) {
	$response=array();


	while ($rows= mysqli_fetch_array($hasil1)) {
		$items=array();


	$items["id_kat"]=$rows["id_kat"];
		$items["id_kue"]=$rows["id_kue"];

		$items["nama_kue"]=$rows["nama_kue"];
		$items["harga"]=$rows["harga"];
		$items["desc"]=$rows["desc"];
		$items["gambar"]="http://10.42.0.1/kueultah/images/".$rows ["gambar"];




		array_push($response, $items);

	}


	echo json_encode($response);
}

	else{
		$response["sukses"] =0;
		$response["message"] ="No Items Found";

	}

?>
