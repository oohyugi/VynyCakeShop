<?php
/* Code for sign up*/
require "koneksi.php";
//check for required fields
if (isset($_POST['nama']) && isset($_POST['username']) && isset($_POST['password'])&& isset($_POST['alamat'])&& isset($_POST['nohp'])) {
	//get data from post
	$nama = $_POST['nama'];
	$password = $_POST['password'];
	$username = $_POST['username'];
  $alamat= $_POST['alamat'];
  $nohp = $_POST['nohp'];
	// using password hash
	$hash = password_hash($password, PASSWORD_DEFAULT);

	$Vusername = mysqli_query($koneksi, "SELECT * FROM  tbl_user WHERE  username='$username' ");
	//check if user exist

		//check if email exist
		if (mysqli_num_rows($Vusername) == 0) {
			//bulide query
			$insert = "INSERT INTO tbl_user (nama,username,password,alamat,nohp) values('$nama','$username','$hash','$alamat','$nohp')";
			//insert to datavase
			$res_ins = mysqli_query($koneksi, $insert);
			//check if saved work fine
			if ($res_ins) {
				//return user info to app
				$post["message"] = "Registration successfull";
				$post['nama'] = "$nama";


			} else {
				//catch database error
				$post["message"] = $koneksi->error;
			}

		} else {
			//Email exist
			$post["message"] = "Username Already Exists";
		}

	//print JSON response
	echo json_encode($post);
} else {
	// required field is missing
	$response["message"] = "Required fields is missing";
	// print JSON response
	echo json_encode($response);
}
?>
