<?php
/**
*
*/
require "koneksi.php";
if (isset($_POST['username']) && isset($_POST['password'])) {
	//get data from post
	$username = $_POST['username'];
	$password = $_POST['password'];
	// using password hash
		$hash = password_hash($password, PASSWORD_DEFAULT);
	$logIn = mysqli_query($koneksi, "SELECT * FROM  tbl_user WHERE username='$username'");
	//check if user exist
	if (mysqli_num_rows($logIn) > 0) {
		$row = mysqli_fetch_array($logIn);
		//check if email exist
		//bulide query
		//check if saved work fine
		if (password_verify($password, $row['password'])) {
			//return user info to app
			$post["code"] = 0;
			$post["message"] = "LogIn successfull";
			$post['nama'] = $row['nama'];
			$post['id_user'] = $row['id_user'];
			$post['nohp'] = $row['nohp'];
			$post['username'] = $row['username'];
      $post['alamat'] = $row['alamat'];
		} else {
			$post["code"] = 2;
			$post["message"] = "Wrong Email or Password";
		}

	} else {
		//name exist
		$post["code"] = 404;
		$post["message"] = "Try again";
	}
	//print JSON response
	echo json_encode($post);
} else {
	// required field is missing
	$post["code"] = 404;
	$response["message"] = "Required field(s) is missing";

	// print JSON response
	echo json_encode($response);
}
?>
