<?php
/* Code for sign up*/
require "koneksi.php";
//check for required fields
if (isset($_POST['id_user']) && isset($_POST['id_kue'])) {
	//get data from post
	$id_user = $_POST['id_user'];
	$id_kue = $_POST['id_kue'];


	// using password hash




			//bulide query
			$insert = "INSERT INTO tbl_keranjang (id_user,id_kue) values('$id_user','$id_kue')";
			//insert to datavase
			$res_ins = mysqli_query($koneksi, $insert);
			//check if saved work fine
			if ($res_ins) {
				//return user info to app
				$post["message"] = "Sukses";
				$post['id_user'] = "$id_user";


			} else {
				//catch database error
				$post["message"] = $koneksi->error;
			}



	//print JSON response
	echo json_encode($post);
} else {
	// required field is missing
	$response["message"] = "Required fields is missing";
	// print JSON response
	echo json_encode($response);
}
?>
