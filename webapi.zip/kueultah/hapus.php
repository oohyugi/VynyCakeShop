<?php

require 'koneksi.php';
$response=array();

if(isset($_GET['id_pesan'])){
$id_Pesan=$_GET['id_pesan'];

$hasil="DELETE FROM tbl_keranjang where id_Pesan='$id_Pesan'";


if(mysqli_query($koneksi,$hasil)){
  $response["kode"] =1;
         $response["pesan"] = "Sukses Hapus";
}else{

 $response["kode"] = 0;
        $response["pesan"] = "Failed To Delete";
}
echo json_encode($response);
}else{
  $response["kode"] = 0;
         $response["pesan"] = "Gagal";
}
?>
