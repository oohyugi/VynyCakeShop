<?php
/**
*
*/
require 'koneksi.php';



$id_user=$_GET['id_user'];

$response=array();

//ambil semua data
$hasil2= mysqli_query($koneksi,"SELECT  SUM(kue.harga)AS total From tbl_keranjang,kue where tbl_keranjang.id_user='$id_user'")or die(mysql_error());

if (mysqli_num_rows($hasil2)>0) {
$rowss= mysqli_fetch_array($hasil2);



	$response["total"] =number_format($rowss['total']);
  


}

	else{

		$response["message"] ="No Items Found";

	}
echo json_encode($response);
?>
