<?php
/**
*
*/
require 'koneksi.php';
$response=array();


$id_user=$_GET['id_user'];



//ambil semua data
$hasil1= mysqli_query($koneksi,"SELECT tbl_user.id_user,tbl_keranjang.*,kue.* From tbl_user,tbl_keranjang,kue where  tbl_keranjang.id_user=tbl_user.id_user and tbl_keranjang.id_kue=kue.id_kue  and tbl_keranjang.id_user='$id_user'" )or die(mysql_error());

if (mysqli_num_rows($hasil1)>0) {

	$response=array();


	while ($rows= mysqli_fetch_array($hasil1)) {
		$items=array();


	$items["id_user"]=$rows["id_user"];
  $items["id_pesan"]=$rows["id_pesan"];
		$items["id_kue"]=$rows["id_kue"];
		$items["nama_kue"]=$rows["nama_kue"];
		$items["harga"]=$rows["harga"];
    	$items["tgl_pesan"]=$rows["tgl_pesan"];

			$hasil2= mysqli_query($koneksi,"SELECT  SUM(kue.harga)AS total From tbl_keranjang,kue where tbl_keranjang.id_user='$id_user'")or die(mysql_error());
					$rowss= mysqli_fetch_array($hasil2);








		array_push($response, $items);

	}


	echo json_encode($response);
}

	else{
		$response["sukses"] =0;
		$response["message"] ="No Items Found";

	}

?>
